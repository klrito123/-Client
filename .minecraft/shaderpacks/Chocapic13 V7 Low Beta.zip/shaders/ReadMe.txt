To do:
-Rework rain lighting
-Optifine options
-High end versions
-Improve fog in buildings/caves
-Fix exposure in caves
-Wavy stuff
-Improve transparencies lighting (not matching solid lighting atm)

Known issues:
-Some blocks may have crazy colors (if not modded please report it to me).
-Enchanted items are not supported and turn objects black.
-While waiting for an optifine patch that correctly change the rendering order, particles and some others objects are using alpha dithering instead of transparency, or transparency is just disabled (so they will not look great at low resolutions).
-Some particles are not displayed while rendered in front of sky




Sharing a modified version of my shaders:
-You are not allowed to claim any of the code included in "Chocapic13' shaders" as your own
-You can share a modified version of my shaders if you respect the following title scheme : " -Name of the shaderpack- (Chocapic13' Shaders edit) "
-You cannot use any monetizing links (for example adfoc.us ; adf.ly)
-The rules of modification and sharing have to be same as the one here (copy paste all these rules in your post and change depending if you allow modification or not), you cannot make your own rules, you can only choose if you allow redistribution.
-I have to be clearly credited
-You cannot redistribute any version older than "Chocapic13' Shaders V4", even if modified
-Common sense : if you want a feature from another shaderpack or want to use a piece of code found on the web, make sure the code is open source. In doubt ask the creator.


Special level of permission; with written permission from Chocapic13, on request if you think your shaderpack is an huge modification from the original:
-Allows to use monetizing links
-Allows to create your own sharing rules
-Shaderpack name can be chosen
-Listed on Chocapic13' shaders official thread
-Chocapic13 still have to be clearly credited


Using this shaderpack in a video or a picture:
-You are allowed to use this shaderpack for screenshots and videos if you give the shaderpack name in the description/message
-You are allowed to use this shaderpack in monetized videos if you respect the rule above.


Minecraft websites:
-The download link must redirect to the download link (adfoc.us) given in the shaderpack's official thread
-There has to be a link to the shaderpack's official thread
-You are not allowed to add any of your own monetizing link on top of mine to the shaderpack download


If you are not sure about what you are allowed to do or not, PM Chocapic13 on http://www.minecraftforum.net/
Not respecting these rules can and will result in a request of thread/download shutdown to the host/administrator, with or without warning. Intellectual property stealing is punished by law.