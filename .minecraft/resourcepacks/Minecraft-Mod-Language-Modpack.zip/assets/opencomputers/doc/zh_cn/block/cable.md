# 线缆

![Salad.](oredict:oc:cable)

连接[电脑](../general/computer.md) 和机器,
 
可以被任意染料染色，之后只和同色或缺省的灰色连接

可以有效防止乱走线

