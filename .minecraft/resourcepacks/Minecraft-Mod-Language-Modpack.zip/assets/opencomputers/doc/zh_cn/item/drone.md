# 无人机

![Big brother is trying to watch you.](item:OpenComputers:item@84)

通过 [无人机箱](droneCase1.md) 在 [装配机](../block/assembler.md)制造. 他们是实体的[机器人](../block/robot.md), 便宜但功能也受限.移动比 [机器人](../block/robot.md)快些, 通常由[电脑](../general/computer.md)的程序控制. 需要烧写过的 [E2PROM](eeprom.md) 启动
