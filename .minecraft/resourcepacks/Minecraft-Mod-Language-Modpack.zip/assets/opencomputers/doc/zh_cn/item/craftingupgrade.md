# 合成升级

![Crafty.](oredict:oc:craftingUpgrade)

允许 [机器人](../block/robot.md)在自己的[物品栏](../item/inventoryUpgrade.md)进行无序和有序合成. 左上的3X3格子将会成为合成空间， 物品将根据合成表重新排布. 合成结果将会回到机器人物品栏. 捡起物品后，会被放在指定格子; 失败则会放在相邻的空格子. 如果没有格子了，物品会被丢出去
