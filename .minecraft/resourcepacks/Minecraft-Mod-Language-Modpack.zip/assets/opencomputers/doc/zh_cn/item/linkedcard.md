# Linked Card

![I feel we some kind of connection.](oredict:oc:linkedCard)

链接卡是特化的[网卡](lanCard.md). 只能成对使用，用来提供P2P通讯. 可以跨维度无限制距离通讯（只要能创造环境的话）. 