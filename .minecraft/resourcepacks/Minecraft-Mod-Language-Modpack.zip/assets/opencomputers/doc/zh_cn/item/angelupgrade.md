# 天使升级

![哈利路亚！.](oredict:oc:angelUpgrade)

允许[机器人 ](../block/robot.md)在空中凭空放置方块，而不用搭一个柱子挨着